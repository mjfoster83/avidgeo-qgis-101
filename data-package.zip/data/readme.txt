Data downloaded from Open Data Boston.

https://data.cityofboston.gov/City-Services/Rodent-Activity-open-cases-9-4-13/ynt4-n6g9

Download date: August 20, 2014

For use with AvidGeoConf workshop 'Intro to QGIS: Make a Map', December 8, 2014.